﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumericSequence.Controllers;
using System.Web;
using System.Web.Mvc;

namespace NumericSeqTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void Testfibonacci()
        {
            HomeController homeController = new HomeController();
            NumericSequence.Models.InputModel model = new NumericSequence.Models.InputModel();
            model.Number = 6;            
            ViewResult result = homeController.fibonacci(model);
          
            Assert.IsNotNull(result, "The result is not a view result");
            ViewDataDictionary viewData = result.ViewData;
            Assert.AreEqual("Index", result.ViewName);

           
        }
    }
}
